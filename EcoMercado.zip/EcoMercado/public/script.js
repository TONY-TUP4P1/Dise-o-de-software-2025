document.addEventListener("DOMContentLoaded", function() {
    localStorage.setItem("progreso", "2"); // Guarda que el usuario está en el paso 2
    document.querySelectorAll(".progress-step")[1].classList.add("active"); // Activa el paso 2
});
